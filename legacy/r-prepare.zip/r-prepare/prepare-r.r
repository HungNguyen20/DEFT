# Installing these packages in this exact order

# install.packages("BiocManager", repos="http://cran.us.r-project.org")

# BiocManager::install('pcalg')

# install.packages('pcalg_2.7-12.tar.gz', repos = NULL, type="source")

# % This does not to run
# install.packages('fastICA_1.1-16.tar.gz', repos = NULL, type="source")




